require('../css/main.css');

import _ from 'lodash';

console.log(_.isEqual(1, 2));

const WHO = 'JS';
let greeter = (who) => 'Hello from ' + who + '!';

document.getElementById('app').appendChild(
  document.createTextNode(greeter(WHO))
);
